<?php
class menu_custom extends languages{

}