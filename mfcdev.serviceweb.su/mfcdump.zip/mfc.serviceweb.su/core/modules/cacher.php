<?php

class cacher_custom extends cacher{

}