<?php 
    class formgenerator extends baseModule{

        /*
            Это код вашего нового модуля.
            Функция lists отвечает за отображение списка элементов
            Функция add - за добавление нового элемента
            Функция edit - за редактирование существующего элемента
            Функция view - за просмотр определенного элемента
            Вы можете как угодно редактировать эти функции, а также, при необходимости, писать свои собственные.
        */

        public static function lists($filterById = array(), $forceAllFields = false){
            return guides::list_items(get_called_class(), $filterById, $forceAllFields);
        }

        public static function add(){
            if(!count($_POST)){ return guides::add_item(get_called_class());}
            else{
                $formFieldsGuide = guides::getGuideByModuleName('formgenerator_fields');
                $postFields = array_keys($_POST['new_fields']);
                $fieldIds = [];
                foreach($_POST['new_fields']['name'] as $i=>$formTitle){
                    $field = $formFieldsGuide->getGuideObjectClass();
                    foreach($postFields as $postField){
                        $field->setValue($postField, $_POST['new_fields'][$postField][$i]);
                    }
                    $fieldIds[] = $field->commit();
                }

                $_POST['groups_fields'] = $fieldIds;
                return guides::add_item(get_called_class());
            }
        }

        public static function edit($itemId = false){
            if(!count($_POST)){  return guides::edit_item(get_called_class(), $itemId);}
            else{
              
                $postFields = array_keys($_POST['fields']);
                $fieldIds = [];

                foreach($_POST['fields']['name'] as $k=>$v){
                  $fields_up=array(); 
                  $fieldIds[]=$k;
                  foreach($postFields as $postField){
                    $fields_up[]="`".addslashes($postField)."`='".addslashes($_POST['fields'][$postField][$k])."'";
                  }
                  self::customQuery("UPDATE `guide_formgenerator_fields` SET ".join(',',$fields_up)." WHERE `id`='".intval($k)."' ");
                }

                if (isset($_POST['form_row_delete'])){
                  $del_list = array();
                  foreach($_POST['form_row_delete'] as $v){
                     $del_list[]=intval($v);
                  }
                  self::customQuery("DELETE FROM `guide_formgenerator_fields` WHERE `id` IN(".join(',',$del_list).") ");
                }
              
                if (isset($_POST['new_fields'])){
                  $formFieldsGuide = guides::getGuideByModuleName('formgenerator_fields');
                  foreach($_POST['new_fields']['name'] as $i=>$formTitle){
                    $field = $formFieldsGuide->getGuideObjectClass();
                    foreach($postFields as $postField){
                       $field->setValue($postField, $_POST['new_fields'][$postField][$i]);
                    }
                    $fieldIds[] = $field->commit();
                  }
                }
              
                $_POST['groups_fields'] = $fieldIds;
                return guides::edit_item(get_called_class(),$itemId);
            }
        }

        public static function view($object = false, $callFromPage = false){
            if(is_numeric($object)){ $object = formgenerator::getById($object);}
            if($object instanceof formgenerator){
                if(!$callFromPage){
                    $page = $object->getConnectedPage();
                    if($page){
                        $pageUrl = $page->getValue('url');
                        if($pageUrl){ utils::redirect('/'.$pageUrl); }
                        else {return array('page'=>$page, 'source'=>$object);}
                    }
                    else{   return array('page'=>false, 'source'=>$object);}
                }
                else{ return $object;}
            }
            else{ return router::err404();}
        }
      
       public static function save_form(){
         print_r($_POST); die;
        }
    }
?>