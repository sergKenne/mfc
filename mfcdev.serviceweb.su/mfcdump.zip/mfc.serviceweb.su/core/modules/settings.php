<?php
    class settings_custom extends settings{

    }