<?php
    class guides_custom extends guides{

    }