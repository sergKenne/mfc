<?php
    class users_custom extends users{

    }