<?php
    class files_custom extends files{

    }