<?php
/**
 * Created by PhpStorm.
 * User: Stardisk
 * Date: 22.06.20
 * Time: 11:10
 */
class permissions_custom extends permissions{
    
}