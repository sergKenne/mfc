<?php
    class languages_custom extends languages{

    }