<?php
    class webforms_custom extends webforms{

    }