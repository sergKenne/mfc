<?php
/**
 * Created by PhpStorm.
 * User: Stardisk
 * Date: 22.04.20
 * Time: 15:24
 */

class autoupdate{

    public static function info(){
        return config::get('General', 'version');
    }

    public static function loadUpdate(){
        file_put_contents('./install.zip', file_get_contents('http://installcms.serviceweb.su/install.zip'));

        $zip = new ZipArchive; $newVersion = 0;
        if($zip->open('./install.zip') === TRUE) {
            $newVersion = $zip->getFromName("version");
            $zip->close();
        }

        if(version_compare($newVersion, self::info(), '>')){ return array('new'=>true, 'version'=>$newVersion);}
        else{
            unlink('./install.zip');
            return array('new'=>false);
        }
    }

    public static function installUpdate(){
        //файлы, в которых может быть пользовательский код, и которые не должны быть перезаписаны обновлением
        $noRewriteFiles = array(
            './core/modules/files.php'=>'',
            './core/modules/guides.php'=>'',
            './core/modules/languages.php'=>'',
            './core/modules/pages.php'=>'',
            './core/modules/menu.php'=>'',
            './core/modules/settings.php'=>'',
            './core/modules/users.php'=>'',
            './core/modules/webforms.php'=>'',
            './core/modules/permissions.php'=>'',
            './templates/default.phtml'=>'',
            './templates/err403.phtml'=>'',
            './templates/err404.phtml'=>'',
            './templates/pages/content.phtml'=>'',
            './templates/pages/main_page.phtml'=>'',
            './templates/pages/parts/numpages.phtml'=>'',
            './templates/pages/parts/breadcrumbs.phtml'=>'',
            './templates/users/edit.phtml'=>'',
            './templates/users/enter.phtml'=>'',
            './templates/users/registrate.phtml'=>'',
            './templates/users/reminder.phtml'=>'',
            './templates/webforms/getForm.phtml'=>'',
            './robots.txt'
        );

//сохраняем их содержимое
        foreach($noRewriteFiles as $noRewriteFile=>$fileData){
            if(file_exists($noRewriteFile)){
                $noRewriteFiles[$noRewriteFile] = file_get_contents($noRewriteFile);
            }
        }

        //распаковываем архив обновления
        $zip = new ZipArchive;
        if($zip->open('install.zip') === TRUE) {
            $zip->extractTo('.');
            $zip->close();
        }
        else{ echo 'Не найден файл установки'; exit;}


//записываем содержимое файлов обратно
        foreach($noRewriteFiles as $noRewriteFile=>$fileData){
            file_put_contents($noRewriteFile, $noRewriteFiles[$noRewriteFile]);
        }

        include('./install_update.php');
    }
}