document.addEventListener('DOMContentLoaded', function(){
    if(site.module == 'services' && site.method == 'lists'){
        document.querySelector('input[type="reset"]').onclick = function(){ location.href = '/services';}
    }
});