<?

/*include('DamaskHelper.php');

$damask = new DamaskHelper();
$offices = $damask->FetchAllOffices();
print_r($offices); die;*/
?>