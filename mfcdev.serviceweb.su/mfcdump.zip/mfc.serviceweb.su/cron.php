<?php
/**
 * Created by PhpStorm.
 * User: Stardisk
 * Date: 12.03.20
 * Time: 12:41
 */

require_once('core/loader.php');

$result['schedule::updateSchedule'] = schedule::updateSchedule();

var_dump($result); exit;
